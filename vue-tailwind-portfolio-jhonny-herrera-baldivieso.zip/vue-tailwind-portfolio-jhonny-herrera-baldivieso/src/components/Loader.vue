<template>
    <div class="flex justify-center items-center">
        <div class="animate-spin rounded-full h-20 w-20 border-t-2 border-b-2 border-blue-600 dark:border-white"></div>
    </div>
</template>

<script setup></script>