<template>
    <div>
        <hr class="border-1 my-8 border-gray-400 sm:w-4/12 mx-auto">
        <div class="text-center my-4 dark:text-white flex items-center justify-center">
            Jhonny Herrera Baldivieso - Developer <a href="https://web.whatsapp.com/" target="_blank"
                class="text-white py-1 px-2 ms-2 rounded-md bg-blue-600">+591 72677902</a>
        </div>
        <div class="text-center">
            <a href="https://www.linkedin.com/in/jhonny-herrera-baldivieso-a44968241/" target="_blank"
                class="m-1 p-1 text-gray-600 text-2xl hover:text-blue-600 dark:text-gray-400"><font-awesome-icon
                    icon="fa-brands fa-linkedin" /></a>
            <a href="https://www.facebook.com/jmoprix" target="_blank"
                class="m-1 p-1 text-gray-600 text-2xl hover:text-blue-600 dark:text-gray-400"><font-awesome-icon
                    icon="fa-brands fa-facebook" /></a>
            <a href="https://www.instagram.com/jhonny_herrera_baldivieso/" target="_blank"
                class="m-1 p-1 text-gray-600 text-2xl hover:text-blue-600 dark:text-gray-400"><font-awesome-icon
                    icon="fa-brands fa-instagram" /></a>
            <a href="https://github.com/jmoprix/" target="_blank"
                class="m-1 p-1 text-gray-600 text-2xl hover:text-blue-600 dark:text-gray-400"> <font-awesome-icon
                    icon="fa-brands fa-github" /></a>
            <a href="https://mail.google.com/" target="_blank"
                class="m-1 p-1 text-gray-600 text-2xl hover:text-blue-600 dark:text-gray-400"> <font-awesome-icon
                    icon="fa-solid fa-envelope" /></a>
        </div>
    </div>
</template>
<script setup></script>