<template>
    <div class="text-center">
        <h2 class="text-center text-xl sm:text-2xl font-bold uppercase dark:text-white">Pproyecto de Diseño Web II</h2>
        <p class="sm:text-center text-justify my-4 sm:w-4/12 mx-auto dark:text-gray-300">
          Hola. Este codigo se está analisando por el estudiante de Ingenieria en Sistenas Jhonny Herrera Baldivieso.
          Le gusta la tecnología y desearía completar un curso de Fullstack. 
          El estudiante quisiera poseer conocimientos de desarrollo web y se encuentra enpesando su tercer año en la Universidad Privada Domingo Sabio.</p>
        <p class="text-center text-blue-600">#DotNetCore #WebApplication</p>
    </div>
</template>
<script setup>
</script>