<template>
    <div>
        <img src="../assets/imgs/profile.png"
            class="w-[180px] h-[180px] sm:w-[200px] sm:h-[200px] mx-auto rounded-full shadow-md">
        <h1 class="mt-8 mb-4 text-center text-3xl sm:text-4xl uppercase font-bold dark:text-white">Jhonny Herrera Baldivieso</h1>
        <hr class="border-1 my-4 border-gray-400 w-14 mx-auto ">
        <p class="text-center text-xl sm:text-2xl text-gray-700 dark:text-gray-300">Fullstack Developer</p>
    </div>
</template>

<script setup></script>
